// Author : IronmanIIITH //


Run npm install in your directory before starting the server

DB and Table structure
column - rollNo, firstName, lastName (here rollNo is mandatory)
database name - test