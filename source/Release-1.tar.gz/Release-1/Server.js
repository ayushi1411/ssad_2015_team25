var express=require('express');
var app=express();
var  mysql=require('mysql');
var Sequelize = require('sequelize');
var sequelize = new Sequelize('data', 'root', 'speed', {
    host: 'localhost',
    dialect: 'mysql',
    pool: {
        max: 5,
        min: 0,
        idle: 10000
    },
});

var connection = mysql.createConnection({
  host     : 'localhost',
  user     : 'root',
  password : 'speed',
  database : 'data'
});

connection.connect();

app.set('views',__dirname + '/views');
app.use(express.static(__dirname + '/JS'));
app.set('view engine', 'ejs');
app.engine('html', require('ejs').renderFile);

app.get('/',function(req,res){
res.render('index.html');
});

app.get('/search',function(req,res){
QueryString = 'select * from data where company like "' + req.query.key + '%";'; 
connection.query(QueryString, function(err, rows, fields) {
	  if (err) throw err;
    var data=[];
    for(i=0;i<rows.length;i++)
      {
        data.push(rows[i].company);
      }
      res.end(JSON.stringify(data));
	});
});

app.get('/getcompanydata',function(req,res) {
    console.log("This is the query -> ");
    console.log(req.query.q);
    QueryString = 'select * from data where company like "%' + req.query.q + '%";';
    sequelize.query(QueryString).spread(function(studentsdata,metadata)
    {
       res.setHeader("Access-Control-Allow-Origin", "*");
       res.json({StudentsDataOut:studentsdata})
       // res.render('demo.html')   
   });
});

// app.get('/phoneinfo',function(req,res)){
//     res.render('phoneinfo.html')
// }
app.get('/phoneinfo',function(req,res) {
    console.log("This is the query -> ");
    console.log(req.query.pid);
    QueryString = 'select * from data where phoneid= '+ req.query.pid + ';';
    sequelize.query(QueryString).spread(function(studentsdata,metadata)
    {
       res.setHeader("Access-Control-Allow-Origin", "*");
       res.render('phoneinfo.html',{StudentsDataOut:studentsdata})
       // res.render('demo.html')   
   });
});



var server=app.listen(3000,function(){
console.log("We have started our server on port 3000");
});
